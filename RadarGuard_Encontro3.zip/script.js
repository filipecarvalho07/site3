const usuario = {
    nome: "Rafael Costa",
    cargo: "Operador de Defesa Aérea",
    nivelAcesso: "Operacional",
    radaresAtivos: 12
};

function testarUsuario() {
    console.log("=== RadarGuard ===");
    console.log("Usuário:", usuario.nome);
    console.log("Cargo:", usuario.cargo);
    console.log("Nível de acesso:", usuario.nivelAcesso);
    console.log("Radares ativos:", usuario.radaresAtivos);
}

function atualizarDashboard() {
    console.log("Dashboard atualizado com sucesso.");
}

testarUsuario();

document.getElementById("refreshBtn").addEventListener("click", atualizarDashboard);
