# RadarGuard — Entregável do Encontro 3

Projeto: Simulador de Defesa Aérea e Gestão de Radares.

## Arquivos
- index.html — Dashboard, perfil e UVP.
- style.css — Grid, Flexbox, sidebar, cards e responsividade.
- script.js — Objeto de usuário, variáveis, funções e testes no console.

## Como executar
Abra o arquivo `index.html` no navegador.

Para verificar o JavaScript:
1. Abra o navegador.
2. Pressione F12.
3. Acesse a aba Console.
4. O objeto do usuário e seus dados serão exibidos.

## Critérios atendidos
Frontend:
- Dashboard estático
- Perfil do usuário
- CSS Grid
- Flexbox
- Sidebar
- Cards de estatísticas

JavaScript:
- Declaração de variáveis
- Objeto de usuário
- Função de teste
- Console

Marketing:
- UVP com público, problema, diferencial e valor da solução.
